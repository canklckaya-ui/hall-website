const { useState } = React;

// ============================================================
// SKETCHY PRIMITIVES — reusable shapes with hand-drawn jitter
// ============================================================
const jitter = (n, amt = 1.5) => n + (Math.random() - 0.5) * amt;

// Hand-drawn rect with slight wobble
function SkRect({ x, y, w, h, fill = "none", stroke = "#1a1a1a", sw = 1.2, dash }) {
  const j = 0.8;
  const path = `M ${jitter(x, j)} ${jitter(y, j)} L ${jitter(x + w, j)} ${jitter(y, j)} L ${jitter(x + w, j)} ${jitter(y + h, j)} L ${jitter(x, j)} ${jitter(y + h, j)} Z`;
  return <path d={path} fill={fill} stroke={stroke} strokeWidth={sw} strokeDasharray={dash} strokeLinejoin="round" />;
}

// Hand-drawn line
function SkLine({ x1, y1, x2, y2, sw = 1.2, stroke = "#1a1a1a", dash }) {
  const mx = (x1 + x2) / 2 + (Math.random() - 0.5) * 1.5;
  const my = (y1 + y2) / 2 + (Math.random() - 0.5) * 1.5;
  return <path d={`M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`} fill="none" stroke={stroke} strokeWidth={sw} strokeDasharray={dash} strokeLinecap="round" />;
}

// Squiggly underline
function Squiggle({ x, y, w, color = "#e87a5d", sw = 2 }) {
  let d = `M ${x} ${y}`;
  const steps = Math.floor(w / 8);
  for (let i = 1; i <= steps; i++) {
    const px = x + (i * w) / steps;
    const py = y + (i % 2 === 0 ? 0 : 3);
    d += ` Q ${px - 4} ${py + (i % 2 === 0 ? -3 : 6)} ${px} ${py}`;
  }
  return <path d={d} fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" />;
}

// Placeholder text bars (lorem)
function TextBars({ x, y, lines = 3, w = 200, gap = 6, sw = 0.8 }) {
  return (
    <g>
      {Array.from({ length: lines }).map((_, i) => (
        <SkLine key={i} x1={x} y1={y + i * gap} x2={x + (i === lines - 1 ? w * 0.6 : w * (0.85 + Math.random() * 0.15))} y2={y + i * gap} sw={sw} stroke="#888" />
      ))}
    </g>
  );
}

// Image placeholder (X box)
function ImgBox({ x, y, w, h, label = "img", fill = "#f0ede5" }) {
  return (
    <g>
      <SkRect x={x} y={y} w={w} h={h} fill={fill} sw={1} />
      <SkLine x1={x} y1={y} x2={x + w} y2={y + h} sw={0.7} stroke="#aaa" />
      <SkLine x1={x + w} y1={y} x2={x} y2={y + h} sw={0.7} stroke="#aaa" />
      <text x={x + w / 2} y={y + h / 2 + 3} textAnchor="middle" fontFamily="JetBrains Mono" fontSize="8" fill="#999" letterSpacing="1">{label.toUpperCase()}</text>
    </g>
  );
}

// Bar chart sketch
function BarChartSketch({ x, y, w, h, bars = [40, 65, 55, 80, 95, 72], color = "#1f3a5f" }) {
  const bw = w / bars.length;
  const max = Math.max(...bars);
  return (
    <g>
      <SkLine x1={x} y1={y + h} x2={x + w} y2={y + h} sw={1.2} />
      <SkLine x1={x} y1={y} x2={x} y2={y + h} sw={1.2} />
      {bars.map((b, i) => {
        const bh = (b / max) * (h - 4);
        return <SkRect key={i} x={x + i * bw + bw * 0.15} y={y + h - bh} w={bw * 0.7} h={bh} fill={color} sw={0.8} />;
      })}
    </g>
  );
}

// Line chart sketch
function LineChartSketch({ x, y, w, h, points = [60, 50, 55, 40, 35, 28, 22, 18, 12, 8], color = "#e87a5d" }) {
  const max = Math.max(...points);
  const pw = w / (points.length - 1);
  let d = "";
  points.forEach((p, i) => {
    const px = x + i * pw;
    const py = y + h - (p / max) * (h - 4);
    d += (i === 0 ? "M" : " L") + ` ${px} ${py}`;
  });
  return (
    <g>
      <SkLine x1={x} y1={y + h} x2={x + w} y2={y + h} sw={1.2} />
      <SkLine x1={x} y1={y} x2={x} y2={y + h} sw={1.2} />
      <path d={d} fill="none" stroke={color} strokeWidth={2.4} strokeLinejoin="round" strokeLinecap="round" />
      {points.map((p, i) => {
        const px = x + i * pw;
        const py = y + h - (p / max) * (h - 4);
        return <circle key={i} cx={px} cy={py} r="2.4" fill={color} />;
      })}
    </g>
  );
}

// Donut sketch
function DonutSketch({ cx, cy, r, segments = [40, 25, 20, 15], colors = ["#1f3a5f", "#e87a5d", "#d4a84b", "#7a2e3e"] }) {
  const total = segments.reduce((a, b) => a + b, 0);
  let acc = -Math.PI / 2;
  return (
    <g>
      {segments.map((s, i) => {
        const ang = (s / total) * Math.PI * 2;
        const x1 = cx + r * Math.cos(acc);
        const y1 = cy + r * Math.sin(acc);
        const x2 = cx + r * Math.cos(acc + ang);
        const y2 = cy + r * Math.sin(acc + ang);
        const large = ang > Math.PI ? 1 : 0;
        const d = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`;
        acc += ang;
        return <path key={i} d={d} fill={colors[i]} stroke="#1a1a1a" strokeWidth="1" />;
      })}
      <circle cx={cx} cy={cy} r={r * 0.5} fill="#fff" stroke="#1a1a1a" strokeWidth="1" />
    </g>
  );
}

// ============================================================
// DIRECTION 1 — "EDITORIAL LEDGER"
// Newsreader serif + grid lines + classical bank/financial report feel.
// White paper, navy ink, single coral accent. Minimal.
// ============================================================
const D1 = {
  bg: "#fdfcf7",
  ink: "#1a2332",
  rule: "#1a2332",
  accent: "#c44d3d",
  muted: "#888",
};

function D1Cover() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <SkLine x1="40" y1="50" x2="760" y2="50" sw={0.4} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">FİZİBİLİTE RAPORU · 14.04.2026 · GİZLİ</text>
      <text x="40" y="170" className="f-news" fontSize="58" fill={D1.ink} fontWeight="600">Dosso Dossi</text>
      <text x="40" y="220" className="f-news" fontSize="58" fill={D1.ink} fontWeight="600" fontStyle="italic">Grubu</text>
      <SkLine x1="40" y1="245" x2="280" y2="245" sw={2} stroke={D1.accent} />
      <text x="40" y="285" className="f-news" fontSize="22" fill={D1.ink}>Finansal Yeniden Yapılandırma</text>
      <text x="40" y="310" className="f-news" fontSize="22" fill={D1.ink}>İş Planı ve Fizibilite Değerlendirme Raporu</text>
      <text x="40" y="395" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="1.5">DANIŞMAN</text>
      <text x="40" y="412" className="f-news" fontSize="12" fill={D1.ink}>Hall Strateji ve Yönetim Danışmanlığı A.Ş.</text>
      <text x="40" y="426" className="f-news" fontSize="11" fill={D1.muted} fontStyle="italic">Can Kılıçkaya · YMM-CPA</text>
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
      {/* corner marker */}
      <text x="760" y="412" className="f-mono" fontSize="9" fill={D1.muted} textAnchor="end" letterSpacing="2">VOL.01</text>
    </svg>
  );
}

function D1Summary() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">02 · YÖNETİCİ ÖZETİ</text>
      <text x="760" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2" textAnchor="end">SAYFA 02 / 23</text>
      <text x="40" y="90" className="f-news" fontSize="32" fill={D1.ink} fontWeight="600">Bir bakışta.</text>
      {/* 4 metric columns */}
      {[
        { k: "117.805", u: "EUR'000", l: "Konsolide Satış" },
        { k: "~14 M", u: "EUR / yıl", l: "FAVÖK" },
        { k: "~253 M", u: "EUR", l: "Gayrimenkul" },
        { k: "~127 M", u: "EUR", l: "Kredi Stoku" },
      ].map((m, i) => (
        <g key={i} transform={`translate(${40 + i * 180}, 130)`}>
          <SkLine x1="0" y1="0" x2="160" y2="0" sw={0.5} stroke={D1.rule} />
          <text x="0" y="22" className="f-mono" fontSize="8" fill={D1.muted} letterSpacing="1.5">0{i + 1}</text>
          <text x="0" y="62" className="f-news" fontSize="28" fill={D1.ink} fontWeight="600">{m.k}</text>
          <text x="0" y="78" className="f-mono" fontSize="9" fill={D1.accent} letterSpacing="1">{m.u}</text>
          <text x="0" y="100" className="f-news" fontSize="12" fill={D1.ink}>{m.l}</text>
        </g>
      ))}
      <SkLine x1="40" y1="250" x2="760" y2="250" sw={0.5} stroke={D1.rule} />
      <text x="40" y="280" className="f-news" fontSize="13" fill={D1.ink} fontStyle="italic">"Operasyonel performans güçlü; vade uyumsuzluğu yapılandırma gerektirmektedir."</text>
      <TextBars x={40} y={310} lines={6} w={700} gap={11} sw={0.6} />
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
    </svg>
  );
}

function D1Section() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">BÖLÜM</text>
      <text x="40" y="180" className="f-mono" fontSize="14" fill={D1.accent} letterSpacing="3">— III</text>
      <text x="40" y="250" className="f-news" fontSize="64" fill={D1.ink} fontWeight="600">Başvuru</text>
      <text x="40" y="310" className="f-news" fontSize="64" fill={D1.ink} fontWeight="600" fontStyle="italic">gerekçeleri.</text>
      <SkLine x1="40" y1="335" x2="200" y2="335" sw={2} stroke={D1.accent} />
      <text x="40" y="375" className="f-news" fontSize="13" fill={D1.muted} fontStyle="italic">Küresel ekonomi · Türkiye konjonktürü · Sektörel etkenler · Grup-spesifik</text>
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
    </svg>
  );
}

function D1Table() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">07 · ŞİRKET BAZLI MALİ VERİLER</text>
      <text x="40" y="80" className="f-news" fontSize="22" fill={D1.ink} fontWeight="600">Konsolide Gelir Tablosu — 2025A (EUR'000)</text>
      {/* table */}
      <SkLine x1="40" y1="105" x2="760" y2="105" sw={1.2} />
      {["Kalem","DDFS","Tekstil","Haliç","Politur","KONSOL."].map((h,i)=>(
        <text key={i} x={i===0?50:160+i*100} y="125" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="1.5">{h}</text>
      ))}
      <SkLine x1="40" y1="135" x2="760" y2="135" sw={0.5} />
      {[
        ["Net Satışlar","24.109","80.715","3.954","9.017","117.805"],
        ["SMM (-)","23.227","66.340","3.160","4.755","97.495"],
        ["Brüt Kâr","882","14.375","794","4.262","20.310"],
        ["FAVÖK","319","9.704","662","3.356","14.042"],
        ["FAVÖK Marjı","%1,3","%12,0","%16,7","%37,2","%11,9"],
      ].map((row,r)=>(
        <g key={r}>
          {row.map((c,i)=>(
            <text key={i} x={i===0?50:160+i*100} y={155+r*30} className="f-news" fontSize={r===4?"12":"14"} fill={r===4?D1.accent:D1.ink} fontStyle={r===4?"italic":""} fontWeight={r===3?"600":"400"}>{c}</text>
          ))}
          <SkLine x1="40" y1={165+r*30} x2="760" y2={165+r*30} sw={0.3} stroke="#ccc" />
        </g>
      ))}
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
    </svg>
  );
}

function D1Chart() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">12 · BORÇ SERVİSİ — 10 YILLIK PROJEKSİYON</text>
      <text x="40" y="80" className="f-news" fontSize="22" fill={D1.ink} fontWeight="600">Dönem Sonu Borç Bakiyesi (EUR'000)</text>
      <text x="40" y="100" className="f-news" fontSize="11" fill={D1.muted} fontStyle="italic">2026T → 2035T · 2035 sonu 0 bakiye</text>
      <BarChartSketch x={60} y={140} w={680} h={230} bars={[126523,132773,135023,120645,106267,91889,77511,63133,48755,34377]} color={D1.ink} />
      {["26","27","28","29","30","31","32","33","34","35"].map((y,i)=>(
        <text key={i} x={60+i*68+34} y="390" className="f-mono" fontSize="9" fill={D1.muted} textAnchor="middle">'{y}</text>
      ))}
      <text x="60" y="135" className="f-mono" fontSize="9" fill={D1.muted}>135.023 zirve</text>
      <text x="740" y="378" className="f-mono" fontSize="9" fill={D1.accent} textAnchor="end">→ 0</text>
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
    </svg>
  );
}

function D1Conclusion() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D1.bg }}>
      <SkLine x1="40" y1="40" x2="760" y2="40" sw={1} stroke={D1.rule} />
      <text x="40" y="34" className="f-mono" fontSize="9" fill={D1.muted} letterSpacing="2">13 · DEĞERLENDİRME VE SONUÇ</text>
      <text x="40" y="100" className="f-news" fontSize="42" fill={D1.ink} fontWeight="600" fontStyle="italic">Yapılandırılmasının</text>
      <text x="40" y="148" className="f-news" fontSize="42" fill={D1.ink} fontWeight="600">uygun olduğu kanaatindeyiz.</text>
      <SkLine x1="40" y1="170" x2="200" y2="170" sw={2} stroke={D1.accent} />
      {[
        ["I.","Güçlü operasyonel performans (FAVÖK ~14M EUR)"],
        ["II.","Teminat gücü: 2,0× kredi bakiyesi"],
        ["III.","Döviz bazlı gelir → kur riskinden korunmuş"],
        ["IV.","Tüm yatırımlar tamamlanmış"],
        ["V.","DSCR ortalama 1,48× — borç servisi kapasitesi güçlü"],
      ].map((r,i)=>(
        <g key={i}>
          <text x="40" y={210+i*32} className="f-news" fontSize="11" fill={D1.accent} letterSpacing="1">{r[0]}</text>
          <text x="80" y={210+i*32} className="f-news" fontSize="14" fill={D1.ink}>{r[1]}</text>
        </g>
      ))}
      <text x="760" y="410" className="f-news" fontSize="11" fill={D1.muted} fontStyle="italic" textAnchor="end">— Can Kılıçkaya, YMM</text>
      <SkLine x1="40" y1="430" x2="760" y2="430" sw={1} stroke={D1.rule} />
    </svg>
  );
}

// ============================================================
// DIRECTION 2 — "MONO GRID DOSSIER"
// JetBrains Mono + structured grid + dossier/audit feel.
// All-caps headers, numbered everything, very systematic.
// ============================================================
const D2 = {
  bg: "#f5f3ec",
  ink: "#0a0a0a",
  accent: "#1f3a5f",
  highlight: "#d4a84b",
  muted: "#666",
};

function D2Frame({ children, num, label, total = 23 }) {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D2.bg }}>
      {/* corner brackets */}
      <SkLine x1="20" y1="20" x2="40" y2="20" sw={1.5} />
      <SkLine x1="20" y1="20" x2="20" y2="40" sw={1.5} />
      <SkLine x1="780" y1="20" x2="760" y2="20" sw={1.5} />
      <SkLine x1="780" y1="20" x2="780" y2="40" sw={1.5} />
      <SkLine x1="20" y1="430" x2="40" y2="430" sw={1.5} />
      <SkLine x1="20" y1="430" x2="20" y2="410" sw={1.5} />
      <SkLine x1="780" y1="430" x2="760" y2="430" sw={1.5} />
      <SkLine x1="780" y1="430" x2="780" y2="410" sw={1.5} />
      {/* header strip */}
      <text x="40" y="44" className="f-mono" fontSize="9" fill={D2.ink} letterSpacing="2">[{num}] {label}</text>
      <text x="760" y="44" className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="2" textAnchor="end">{num}/{total}</text>
      <SkLine x1="40" y1="55" x2="760" y2="55" sw={0.6} />
      {/* footer */}
      <SkLine x1="40" y1="410" x2="760" y2="410" sw={0.6} />
      <text x="40" y="425" className="f-mono" fontSize="8" fill={D2.muted} letterSpacing="2">DOSSO DOSSI · FYY 2026</text>
      <text x="760" y="425" className="f-mono" fontSize="8" fill={D2.muted} letterSpacing="2" textAnchor="end">HALL STRATEJİ</text>
      {children}
    </svg>
  );
}

function D2Cover() {
  return (
    <D2Frame num="00" label="KAPAK">
      <text x="40" y="120" className="f-mono" fontSize="10" fill={D2.accent} letterSpacing="3">FİZİBİLİTE / 5411 SK. GEÇ. 32. MD.</text>
      <text x="40" y="200" className="f-mono" fontSize="48" fill={D2.ink} fontWeight="500" letterSpacing="-1">DOSSO DOSSI</text>
      <text x="40" y="244" className="f-mono" fontSize="48" fill={D2.ink} fontWeight="500" letterSpacing="-1">GRUBU.</text>
      <SkRect x="40" y="270" w="280" h="40" fill={D2.highlight} sw={1} />
      <text x="50" y="296" className="f-mono" fontSize="13" fill={D2.ink} letterSpacing="1">FİNANSAL YENİDEN YAPILANDIRMA</text>
      <SkLine x1="40" y1="340" x2="760" y2="340" sw={0.5} />
      <text x="40" y="362" className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="2">DANIŞMAN</text>
      <text x="40" y="380" className="f-mono" fontSize="11" fill={D2.ink}>HALL STRATEJİ VE YÖNETİM DANIŞMANLIĞI A.Ş.</text>
      <text x="500" y="362" className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="2">TARİH</text>
      <text x="500" y="380" className="f-mono" fontSize="11" fill={D2.ink}>14.04.2026 · İSTANBUL</text>
    </D2Frame>
  );
}

function D2Summary() {
  return (
    <D2Frame num="02" label="YÖNETİCİ ÖZETİ">
      <text x="40" y="90" className="f-mono" fontSize="22" fill={D2.ink} letterSpacing="-0.5">Bir bakışta.</text>
      {[
        ["117.805", "EUR'000", "KONSOLİDE SATIŞ"],
        ["~14M", "EUR/YIL", "FAVÖK"],
        ["~253M", "EUR", "GAYRİMENKUL"],
        ["~127M", "EUR", "KREDİ STOKU"],
      ].map((m, i) => (
        <g key={i}>
          <SkRect x={40 + i * 180} y={120} w={170} h={120} fill="#fff" sw={1} />
          <text x={50 + i * 180} y={145} className="f-mono" fontSize="9" fill={D2.accent} letterSpacing="2">METR.0{i + 1}</text>
          <text x={50 + i * 180} y={195} className="f-mono" fontSize="28" fill={D2.ink} fontWeight="500">{m[0]}</text>
          <text x={50 + i * 180} y={213} className="f-mono" fontSize="9" fill={D2.highlight} letterSpacing="1">{m[1]}</text>
          <text x={50 + i * 180} y={232} className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="1.5">{m[2]}</text>
        </g>
      ))}
      <SkRect x="40" y="265" w="720" h="120" fill="#fff" sw={1} />
      <text x="50" y="285" className="f-mono" fontSize="9" fill={D2.accent} letterSpacing="2">▸ ÖZET BULGU</text>
      <TextBars x={50} y={305} lines={5} w={700} gap={13} sw={0.7} />
    </D2Frame>
  );
}

function D2Section() {
  return (
    <D2Frame num="03" label="BÖLÜM AÇILIŞI">
      <text x="40" y="160" className="f-mono" fontSize="10" fill={D2.muted} letterSpacing="3">— BÖLÜM 03 —</text>
      <text x="40" y="220" className="f-mono" fontSize="36" fill={D2.ink} fontWeight="500" letterSpacing="-0.5">FYY BAŞVURU</text>
      <text x="40" y="260" className="f-mono" fontSize="36" fill={D2.ink} fontWeight="500" letterSpacing="-0.5">GEREKÇELERİ.</text>
      <SkRect x="40" y="290" w="60" h="14" fill={D2.highlight} sw={0.8} />
      {["3.1 KÜRESEL EKONOMİK GELİŞMELER","3.2 TÜRKİYE EKONOMİSİ VE KUR BASKISI","3.3 İHRACAT REKABETİ VE TURİZM","3.4 GRUP SPESİFİK ETKENLER"].map((s,i)=>(
        <text key={i} x="40" y={335+i*20} className="f-mono" fontSize="11" fill={D2.ink} letterSpacing="1">{s}</text>
      ))}
    </D2Frame>
  );
}

function D2Table() {
  return (
    <D2Frame num="07" label="MALİ VERİLER">
      <text x="40" y="80" className="f-mono" fontSize="16" fill={D2.ink} letterSpacing="-0.3">KONSOLİDE GELİR TABLOSU · 2025A</text>
      <text x="40" y="98" className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="2">EUR'000</text>
      <SkRect x="40" y="115" w="720" h="270" fill="#fff" sw={1} />
      <SkLine x1="40" y1="140" x2="760" y2="140" sw={0.6} />
      {["KALEM","DDFS","TEKSTİL","HALİÇ","POLİTUR","KONSOL."].map((h,i)=>(
        <text key={i} x={i===0?50:120+i*110} y="133" className="f-mono" fontSize="8" fill={D2.muted} letterSpacing="2">{h}</text>
      ))}
      {[
        ["Net Satışlar","24.109","80.715","3.954","9.017","117.805"],
        ["SMM (-)","23.227","66.340","3.160","4.755","97.495"],
        ["Brüt Kâr","882","14.375","794","4.262","20.310"],
        ["Faaliyet Gid.","563","4.669","132","906","6.268"],
        ["FAVÖK","319","9.704","662","3.356","14.042"],
        ["FAVÖK %","%1,3","%12,0","%16,7","%37,2","%11,9"],
      ].map((row,r)=>(
        <g key={r}>
          {row.map((c,i)=>(
            <text key={i} x={i===0?50:120+i*110} y={165+r*32} className="f-mono" fontSize={r===4?"13":"11"} fill={r===4?D2.accent:D2.ink} fontWeight={r===4?"600":"400"}>{c}</text>
          ))}
          {r<5 && <SkLine x1="40" y1={175+r*32} x2="760" y2={175+r*32} sw={0.25} stroke="#ddd" />}
        </g>
      ))}
    </D2Frame>
  );
}

function D2Chart() {
  return (
    <D2Frame num="12" label="BORÇ SERVİSİ">
      <text x="40" y="80" className="f-mono" fontSize="16" fill={D2.ink} letterSpacing="-0.3">BORÇ BAKİYESİ + DSCR · 2026T-2035T</text>
      <SkRect x="40" y="105" w="720" h="290" fill="#fff" sw={1} />
      <BarChartSketch x={60} y={140} w={680} h={200} bars={[132773,135023,120645,106267,91889,77511,63133,48755,34377,0]} color={D2.accent} />
      <LineChartSketch x={60} y={140} w={680} h={200} points={[143,136,112,129,145,148,161,181,212,116].map(v=>v-100)} color={D2.highlight} />
      {["26","27","28","29","30","31","32","33","34","35"].map((y,i)=>(
        <text key={i} x={60+i*68+34} y="360" className="f-mono" fontSize="9" fill={D2.muted} textAnchor="middle">'{y}</text>
      ))}
      <SkRect x="60" y="375" w="10" h="6" fill={D2.accent} sw={0.5} />
      <text x="76" y="382" className="f-mono" fontSize="9" fill={D2.ink}>BORÇ BAKİYESİ</text>
      <SkLine x1="200" y1="378" x2="220" y2="378" sw={2} stroke={D2.highlight} />
      <text x="226" y="382" className="f-mono" fontSize="9" fill={D2.ink}>DSCR (×100)</text>
    </D2Frame>
  );
}

function D2Conclusion() {
  return (
    <D2Frame num="13" label="SONUÇ">
      <text x="40" y="100" className="f-mono" fontSize="11" fill={D2.accent} letterSpacing="3">▸ KARAR</text>
      <text x="40" y="160" className="f-mono" fontSize="36" fill={D2.ink} fontWeight="500" letterSpacing="-1">FYY KAPSAMINDA</text>
      <text x="40" y="200" className="f-mono" fontSize="36" fill={D2.ink} fontWeight="500" letterSpacing="-1">UYGUNDUR.</text>
      <SkRect x="40" y="220" w="280" h="20" fill={D2.highlight} sw={1} />
      <text x="50" y="235" className="f-mono" fontSize="11" fill={D2.ink} letterSpacing="1">DSCR ORT. 1,48× · 2035 BAKİYE = 0</text>
      <SkLine x1="40" y1="270" x2="760" y2="270" sw={0.5} />
      {[
        ["01","FAVÖK ~14M EUR"],
        ["02","Teminat 2,0× borç"],
        ["03","Döviz bazlı gelir"],
        ["04","Yatırımlar tamam"],
      ].map((r,i)=>(
        <g key={i}>
          <text x={40+i*180} y="300" className="f-mono" fontSize="9" fill={D2.muted} letterSpacing="2">{r[0]}</text>
          <text x={40+i*180} y="330" className="f-mono" fontSize="13" fill={D2.ink}>{r[1]}</text>
        </g>
      ))}
    </D2Frame>
  );
}

// ============================================================
// DIRECTION 3 — "BANK CIRCULAR"
// Inter sans + heavy navy blocks + structured cards.
// Looks like McKinsey/PwC bank pitch deck. Clean, corporate.
// ============================================================
const D3 = {
  bg: "#ffffff",
  ink: "#0d1b2a",
  navy: "#1f3a5f",
  navyDark: "#0d1b2a",
  accent: "#c9a35a",
  light: "#f3f1ea",
  muted: "#7a7a7a",
};

function D3Cover() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.bg }}>
      <SkRect x="0" y="0" w="800" h="450" fill={D3.navyDark} sw={0} />
      <SkRect x="0" y="0" w="280" h="450" fill={D3.navy} sw={0} />
      <SkRect x="40" y="40" w="40" h="3" fill={D3.accent} sw={0} />
      <text x="40" y="80" className="f-inter" fontSize="9" fill={D3.accent} fontWeight="500" letterSpacing="3">FİZİBİLİTE RAPORU</text>
      <text x="40" y="170" className="f-inter" fontSize="44" fill="#fff" fontWeight="700" letterSpacing="-1">Dosso</text>
      <text x="40" y="210" className="f-inter" fontSize="44" fill="#fff" fontWeight="700" letterSpacing="-1">Dossi</text>
      <text x="40" y="250" className="f-inter" fontSize="44" fill={D3.accent} fontWeight="300" fontStyle="italic">Grubu</text>
      <text x="320" y="180" className="f-inter" fontSize="22" fill="#fff" fontWeight="600">Finansal Yeniden Yapılandırma</text>
      <text x="320" y="208" className="f-inter" fontSize="22" fill="#fff" fontWeight="300">İş Planı ve Fizibilite Değerlendirmesi</text>
      <SkRect x="320" y="225" w="60" h="2" fill={D3.accent} sw={0} />
      <text x="320" y="260" className="f-inter" fontSize="11" fill="rgba(255,255,255,0.6)">5411 sk. Geçici 32. md. kapsamında</text>
      <SkLine x1="320" y1="395" x2="760" y2="395" sw={0.5} stroke="rgba(255,255,255,0.3)" />
      <text x="320" y="415" className="f-inter" fontSize="9" fill={D3.accent} fontWeight="600" letterSpacing="2">DANIŞMAN</text>
      <text x="320" y="430" className="f-inter" fontSize="11" fill="#fff">Hall Strateji ve Yönetim Danışmanlığı A.Ş.</text>
      <text x="760" y="430" className="f-inter" fontSize="9" fill="rgba(255,255,255,0.5)" textAnchor="end">14.04.2026</text>
    </svg>
  );
}

function D3Summary() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.bg }}>
      <SkRect x="0" y="0" w="800" h="60" fill={D3.navy} sw={0} />
      <SkRect x="40" y="22" w="3" h="16" fill={D3.accent} sw={0} />
      <text x="56" y="36" className="f-inter" fontSize="11" fill="#fff" fontWeight="600">02 · Yönetici Özeti</text>
      <text x="760" y="36" className="f-inter" fontSize="9" fill="rgba(255,255,255,0.6)" textAnchor="end" letterSpacing="1">02 / 23</text>

      <text x="40" y="100" className="f-inter" fontSize="28" fill={D3.ink} fontWeight="700" letterSpacing="-0.5">Operasyonel performans güçlü.</text>
      <text x="40" y="124" className="f-inter" fontSize="14" fill={D3.muted}>Vade uyumsuzluğu yapılandırma gerektirmektedir.</text>

      {[
        ["117.805", "EUR'000", "Konsolide Satış", D3.navy],
        ["14.042", "EUR'000", "FAVÖK", D3.navy],
        ["253M", "EUR", "Gayrimenkul", D3.accent],
        ["127M", "EUR", "Kredi Stoku", D3.accent],
      ].map((m, i) => (
        <g key={i}>
          <SkRect x={40 + i * 180} y={160} w={170} h={130} fill={D3.light} sw={0.5} />
          <SkRect x={40 + i * 180} y={160} w={170} h={4} fill={m[3]} sw={0} />
          <text x={50 + i * 180} y={195} className="f-inter" fontSize="9" fill={D3.muted} letterSpacing="1.5" fontWeight="600">0{i + 1}</text>
          <text x={50 + i * 180} y={235} className="f-inter" fontSize="28" fill={D3.ink} fontWeight="700">{m[0]}</text>
          <text x={50 + i * 180} y={252} className="f-inter" fontSize="10" fill={m[3]} fontWeight="600">{m[1]}</text>
          <text x={50 + i * 180} y={275} className="f-inter" fontSize="11" fill={D3.ink}>{m[2]}</text>
        </g>
      ))}

      <SkRect x="40" y="315" w="720" h="100" fill={D3.light} sw={0.5} />
      <SkRect x="40" y="315" w="3" h="100" fill={D3.accent} sw={0} />
      <text x="56" y="340" className="f-inter" fontSize="10" fill={D3.accent} fontWeight="600" letterSpacing="1.5">▸ TEMEL BULGU</text>
      <TextBars x={56} y={355} lines={4} w={680} gap={13} sw={0.7} />
    </svg>
  );
}

function D3Section() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.navyDark }}>
      <SkRect x="0" y="0" w="6" h="450" fill={D3.accent} sw={0} />
      <text x="40" y="100" className="f-inter" fontSize="11" fill={D3.accent} fontWeight="600" letterSpacing="3">BÖLÜM 03</text>
      <text x="40" y="200" className="f-inter" fontSize="56" fill="#fff" fontWeight="700" letterSpacing="-2">Başvuru</text>
      <text x="40" y="252" className="f-inter" fontSize="56" fill="#fff" fontWeight="300" fontStyle="italic" letterSpacing="-1">gerekçeleri.</text>
      <SkRect x="40" y="280" w="80" h="3" fill={D3.accent} sw={0} />
      {["3.1  Küresel Ekonomik Gelişmeler","3.2  Türkiye Ekonomisi ve Kur Baskısı","3.3  İhracat Rekabeti ve Turizm Sektörüne Etkiler","3.4  Grup Şirket Faaliyetleri Spesifik Etkenler"].map((s,i)=>(
        <text key={i} x="40" y={325+i*22} className="f-inter" fontSize="13" fill="rgba(255,255,255,0.75)">{s}</text>
      ))}
    </svg>
  );
}

function D3Table() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.bg }}>
      <SkRect x="0" y="0" w="800" h="60" fill={D3.navy} sw={0} />
      <SkRect x="40" y="22" w="3" h="16" fill={D3.accent} sw={0} />
      <text x="56" y="36" className="f-inter" fontSize="11" fill="#fff" fontWeight="600">07 · Mali Veriler</text>

      <text x="40" y="100" className="f-inter" fontSize="22" fill={D3.ink} fontWeight="700">Konsolide Gelir Tablosu</text>
      <text x="40" y="120" className="f-inter" fontSize="11" fill={D3.muted}>2025 fiili · EUR'000 · 4 grup şirketi konsolidasyonu</text>

      <SkRect x="40" y="140" w="720" h="32" fill={D3.navy} sw={0} />
      {["Kalem","DDFS","Tekstil","Haliç","Politur","Konsolide"].map((h,i)=>(
        <text key={i} x={i===0?56:130+i*108} y="161" className="f-inter" fontSize="10" fill="#fff" fontWeight="600" letterSpacing="1">{h}</text>
      ))}
      {[
        ["Net Satışlar","24.109","80.715","3.954","9.017","117.805"],
        ["SMM","23.227","66.340","3.160","4.755","97.495"],
        ["Brüt Kâr","882","14.375","794","4.262","20.310"],
        ["FAVÖK","319","9.704","662","3.356","14.042"],
        ["FAVÖK Marjı","%1,3","%12,0","%16,7","%37,2","%11,9"],
      ].map((row,r)=>(
        <g key={r}>
          <SkRect x="40" y={172+r*36} w="720" h="36" fill={r%2===0?D3.light:"#fff"} sw={0} />
          {row.map((c,i)=>(
            <text key={i} x={i===0?56:130+i*108} y={195+r*36} className="f-inter" fontSize={r===4?"12":"13"} fill={r===4?D3.accent:D3.ink} fontWeight={r===3||r===4?"700":"400"}>{c}</text>
          ))}
        </g>
      ))}
    </svg>
  );
}

function D3Chart() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.bg }}>
      <SkRect x="0" y="0" w="800" h="60" fill={D3.navy} sw={0} />
      <SkRect x="40" y="22" w="3" h="16" fill={D3.accent} sw={0} />
      <text x="56" y="36" className="f-inter" fontSize="11" fill="#fff" fontWeight="600">12 · Borç Servisi Analizi</text>

      <text x="40" y="100" className="f-inter" fontSize="22" fill={D3.ink} fontWeight="700">10 yıllık borç bakiyesi.</text>
      <text x="40" y="120" className="f-inter" fontSize="11" fill={D3.muted}>EUR'000 · 2026T → 2035T · Anapara ödemesi 2028'de başlıyor</text>

      <SkRect x="40" y="150" w="720" h="240" fill={D3.light} sw={0.5} />
      <BarChartSketch x={70} y={170} w={660} h={190} bars={[132773,135023,120645,106267,91889,77511,63133,48755,34377,0]} color={D3.navy} />
      {["26","27","28","29","30","31","32","33","34","35"].map((y,i)=>(
        <text key={i} x={70+i*66+33} y="380" className="f-inter" fontSize="10" fill={D3.muted} textAnchor="middle">'{y}</text>
      ))}
      <SkRect x="40" y="405" w="170" h="30" fill={D3.navyDark} sw={0} />
      <text x="50" y="423" className="f-inter" fontSize="10" fill="#fff" fontWeight="600">2035: Sıfır bakiye →</text>
      <text x="220" y="423" className="f-inter" fontSize="10" fill={D3.muted}>DSCR ort. 1,48× · max 2,12×</text>
    </svg>
  );
}

function D3Conclusion() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D3.bg }}>
      <SkRect x="0" y="0" w="800" h="60" fill={D3.navy} sw={0} />
      <SkRect x="40" y="22" w="3" h="16" fill={D3.accent} sw={0} />
      <text x="56" y="36" className="f-inter" fontSize="11" fill="#fff" fontWeight="600">13 · Sonuç</text>

      <text x="40" y="110" className="f-inter" fontSize="14" fill={D3.accent} fontWeight="600" letterSpacing="2">DEĞERLENDİRME</text>
      <text x="40" y="160" className="f-inter" fontSize="38" fill={D3.ink} fontWeight="700" letterSpacing="-1">Yapılandırılmasının uygun</text>
      <text x="40" y="200" className="f-inter" fontSize="38" fill={D3.ink} fontWeight="300" fontStyle="italic" letterSpacing="-1">olduğu kanaatindeyiz.</text>

      {[
        ["01","Operasyonel güç","FAVÖK ~14M EUR/yıl"],
        ["02","Teminat","2,0× kredi bakiyesi"],
        ["03","Kur riski yok","Döviz bazlı gelir"],
        ["04","Yatırım tamam","Yeni kredi yok"],
      ].map((r,i)=>(
        <g key={i}>
          <SkRect x={40+i*180} y={250} w={170} h={130} fill={D3.light} sw={0.5} />
          <SkRect x={40+i*180} y={250} w={170} h={3} fill={D3.accent} sw={0} />
          <text x={50+i*180} y={278} className="f-inter" fontSize="9" fill={D3.accent} fontWeight="700" letterSpacing="2">{r[0]}</text>
          <text x={50+i*180} y={310} className="f-inter" fontSize="14" fill={D3.ink} fontWeight="700">{r[1]}</text>
          <text x={50+i*180} y={335} className="f-inter" fontSize="11" fill={D3.muted}>{r[2]}</text>
        </g>
      ))}
      <text x="760" y="425" className="f-inter" fontSize="9" fill={D3.muted} textAnchor="end" fontStyle="italic">Can Kılıçkaya, YMM-CPA</text>
    </svg>
  );
}

// ============================================================
// DIRECTION 4 — "QUIET PAPER"
// Newsreader serif + lots of whitespace + minimal accents.
// Almost like a typeset book chapter. Restrained, dignified.
// Single deep burgundy + warm cream + thin rules.
// ============================================================
const D4 = {
  bg: "#fbf8f1",
  ink: "#2a2420",
  accent: "#7a2e3e",
  rule: "#2a2420",
  muted: "#8a7a6e",
};

function D4Cover() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      {/* large blank space, single rule */}
      <SkLine x1="60" y1="60" x2="100" y2="60" sw={1.5} stroke={D4.accent} />
      <text x="60" y="78" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="3">DOSSO DOSSI GRUBU · 2026</text>

      <text x="60" y="240" className="f-news" fontSize="62" fill={D4.ink} fontWeight="400" fontStyle="italic" letterSpacing="-1">Fizibilite</text>
      <text x="60" y="300" className="f-news" fontSize="62" fill={D4.ink} fontWeight="400" letterSpacing="-1">Raporu.</text>

      <SkLine x1="60" y1="340" x2="180" y2="340" sw={0.6} />
      <text x="60" y="365" className="f-news" fontSize="14" fill={D4.muted} fontStyle="italic">Finansal Yeniden Yapılandırma · İş Planı ve Değerlendirme</text>

      <SkLine x1="60" y1="410" x2="740" y2="410" sw={0.4} />
      <text x="60" y="425" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2">HALL STRATEJİ · CAN KILIÇKAYA · YMM-CPA</text>
      <text x="740" y="425" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2" textAnchor="end">İSTANBUL · 14.IV.MMXXVI</text>
    </svg>
  );
}

function D4Summary() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      <text x="60" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2">II.</text>
      <text x="740" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2" textAnchor="end">YÖNETİCİ ÖZETİ</text>
      <SkLine x1="60" y1="62" x2="740" y2="62" sw={0.4} />

      <text x="60" y="115" className="f-news" fontSize="38" fill={D4.ink} fontStyle="italic">Bir bakışta.</text>

      {/* metrics — typeset, no boxes */}
      {[
        ["117.805", "EUR'000", "konsolide satış"],
        ["14 M", "EUR / yıl", "FAVÖK"],
        ["253 M", "EUR", "gayrimenkul"],
        ["127 M", "EUR", "kredi stoku"],
      ].map((m,i)=>(
        <g key={i} transform={`translate(${60+i*175},170)`}>
          <text x="0" y="0" className="f-news" fontSize="42" fill={D4.ink} fontWeight="500" letterSpacing="-1">{m[0]}</text>
          <text x="0" y="20" className="f-mono" fontSize="9" fill={D4.accent} letterSpacing="2">{m[1]}</text>
          <SkLine x1="0" y1="32" x2="40" y2="32" sw={0.6} stroke={D4.accent} />
          <text x="0" y="52" className="f-news" fontSize="13" fill={D4.muted} fontStyle="italic">{m[2]}</text>
        </g>
      ))}

      <SkLine x1="60" y1="280" x2="160" y2="280" sw={0.6} stroke={D4.accent} />
      <text x="60" y="320" className="f-news" fontSize="20" fill={D4.ink} fontStyle="italic">"Operasyonel performans güçlü;</text>
      <text x="60" y="346" className="f-news" fontSize="20" fill={D4.ink}>vade uyumsuzluğu yapılandırma gerektirmektedir."</text>
      <TextBars x={60} y={385} lines={2} w={680} gap={14} sw={0.6} />
    </svg>
  );
}

function D4Section() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      <SkLine x1="60" y1="60" x2="740" y2="60" sw={0.4} />
      <text x="400" y="195" className="f-mono" fontSize="11" fill={D4.accent} letterSpacing="6" textAnchor="middle">III.</text>
      <text x="400" y="260" className="f-news" fontSize="48" fill={D4.ink} fontStyle="italic" textAnchor="middle">Başvuru gerekçeleri.</text>
      <SkLine x1="350" y1="285" x2="450" y2="285" sw={0.6} stroke={D4.accent} />
      <text x="400" y="320" className="f-news" fontSize="13" fill={D4.muted} textAnchor="middle" fontStyle="italic">Küresel ekonomi · Türkiye konjonktürü · sektörel ve grup-spesifik etkenler</text>
      <SkLine x1="60" y1="410" x2="740" y2="410" sw={0.4} />
    </svg>
  );
}

function D4Table() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      <text x="60" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2">VII.</text>
      <text x="740" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2" textAnchor="end">MALİ VERİLER</text>
      <SkLine x1="60" y1="62" x2="740" y2="62" sw={0.4} />

      <text x="60" y="105" className="f-news" fontSize="26" fill={D4.ink} fontStyle="italic">Konsolide Gelir Tablosu, 2025.</text>
      <text x="60" y="125" className="f-news" fontSize="11" fill={D4.muted} fontStyle="italic">EUR'000 · dört grup şirketi</text>

      {/* clean typeset table — minimal lines */}
      <SkLine x1="60" y1="155" x2="740" y2="155" sw={0.6} />
      {["Kalem","DDFS","Tekstil","Haliç","Politur","Konsolide"].map((h,i)=>(
        <text key={i} x={i===0?60:140+i*110} y="148" className="f-mono" fontSize="8" fill={D4.muted} letterSpacing="2">{h}</text>
      ))}
      {[
        ["Net Satışlar","24.109","80.715","3.954","9.017","117.805"],
        ["Satışların Maliyeti","23.227","66.340","3.160","4.755","97.495"],
        ["Brüt Kâr","882","14.375","794","4.262","20.310"],
        ["FAVÖK","319","9.704","662","3.356","14.042"],
        ["FAVÖK Marjı","%1,3","%12,0","%16,7","%37,2","%11,9"],
      ].map((row,r)=>(
        <g key={r}>
          {row.map((c,i)=>(
            <text key={i} x={i===0?60:140+i*110} y={185+r*36} className="f-news" fontSize={r===3||r===4?"15":"13"} fill={r===4?D4.accent:D4.ink} fontStyle={r===4?"italic":""} fontWeight={r===3?"600":"400"}>{c}</text>
          ))}
        </g>
      ))}
      <SkLine x1="60" y1="370" x2="740" y2="370" sw={0.6} />
      <text x="60" y="395" className="f-news" fontSize="10" fill={D4.muted} fontStyle="italic">— Kaynak: Hall Strateji düzeltilmiş konsolidasyon, 31.12.2025.</text>
    </svg>
  );
}

function D4Chart() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      <text x="60" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2">XII.</text>
      <text x="740" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2" textAnchor="end">BORÇ SERVİSİ</text>
      <SkLine x1="60" y1="62" x2="740" y2="62" sw={0.4} />

      <text x="60" y="105" className="f-news" fontSize="26" fill={D4.ink} fontStyle="italic">10 yıllık borç bakiyesi.</text>
      <text x="60" y="125" className="f-news" fontSize="11" fill={D4.muted} fontStyle="italic">2026T → 2035T sonu sıfır bakiye</text>

      <BarChartSketch x={80} y={170} w={640} h={200} bars={[132,135,120,106,91,77,63,48,34,0]} color={D4.accent} />
      {["26","27","28","29","30","31","32","33","34","35"].map((y,i)=>(
        <text key={i} x={80+i*64+32} y="390" className="f-news" fontSize="11" fill={D4.muted} textAnchor="middle" fontStyle="italic">'{y}</text>
      ))}
      <SkLine x1="60" y1="410" x2="740" y2="410" sw={0.4} />
      <text x="60" y="425" className="f-news" fontSize="10" fill={D4.muted} fontStyle="italic">DSCR ort. 1,48× · 2035 sonu kümülatif nakit +6.034 EUR'000.</text>
    </svg>
  );
}

function D4Conclusion() {
  return (
    <svg viewBox="0 0 800 450" style={{ width: "100%", height: "100%", background: D4.bg }}>
      <text x="60" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2">XIII.</text>
      <text x="740" y="50" className="f-mono" fontSize="9" fill={D4.muted} letterSpacing="2" textAnchor="end">SONUÇ</text>
      <SkLine x1="60" y1="62" x2="740" y2="62" sw={0.4} />

      <text x="60" y="180" className="f-news" fontSize="44" fill={D4.ink} fontStyle="italic" letterSpacing="-0.5">Yapılandırılmasının</text>
      <text x="60" y="225" className="f-news" fontSize="44" fill={D4.ink} letterSpacing="-0.5">uygun olduğu</text>
      <text x="60" y="270" className="f-news" fontSize="44" fill={D4.accent} fontStyle="italic" letterSpacing="-0.5">kanaatindeyiz.</text>

      <SkLine x1="60" y1="295" x2="180" y2="295" sw={0.6} />
      {[
        "Operasyonel performans güçlü (FAVÖK ~14M EUR).",
        "Teminat gücü 2,0× kredi bakiyesi.",
        "Döviz bazlı gelir, kur riskinden korunmuş.",
        "Tüm yatırımlar tamamlanmış, yeni kredi yok.",
      ].map((s,i)=>(
        <text key={i} x="60" y={325+i*22} className="f-news" fontSize="13" fill={D4.muted} fontStyle="italic">— {s}</text>
      ))}
      <text x="740" y="425" className="f-news" fontSize="11" fill={D4.muted} textAnchor="end" fontStyle="italic">Can Kılıçkaya, YMM-CPA</text>
    </svg>
  );
}

// ============================================================
// MAIN APP
// ============================================================
const DIRECTIONS = [
  {
    id: "d1",
    title: "Editorial Ledger",
    desc: "Klasik finans yayını / banka raporu hissi. Newsreader serif tipografi, ince çizgi sistemleri, beyaz kağıt zemin. Tek coral aksan rakam vurguları için. Sakin, otoriter, klasik.",
    tags: ["Serif", "Beyaz/Krem", "Coral aksan", "Klasik rapor"],
    slides: [D1Cover, D1Summary, D1Section, D1Table, D1Chart, D1Conclusion],
    labels: ["Kapak", "Yönetici Özeti", "Bölüm Açılışı", "Mali Tablo", "Borç Servisi", "Sonuç"],
  },
  {
    id: "d2",
    title: "Mono Grid Dossier",
    desc: "Denetim raporu / dosye estetiği. JetBrains Mono tipografisi, köşe köşeli çerçeveler, numaralandırılmış her şey. Hardal aksan + lacivert. Sistematik, mühendis bakışlı.",
    tags: ["Monospace", "Krem zemin", "Hardal+Lacivert", "Dosye/Audit"],
    slides: [D2Cover, D2Summary, D2Section, D2Table, D2Chart, D2Conclusion],
    labels: ["Kapak", "Yönetici Özeti", "Bölüm Açılışı", "Mali Tablo", "Borç Servisi", "Sonuç"],
  },
  {
    id: "d3",
    title: "Bank Circular",
    desc: "Kurumsal banka pitch deck'i. Inter sans-serif, koyu lacivert başlık şeritleri, altın aksan. Kart tabanlı bilgi blokları, modern ve self-confident. Yatırımcı sunumu hissi.",
    tags: ["Sans-serif", "Lacivert+Altın", "Kart sistemi", "Modern kurumsal"],
    slides: [D3Cover, D3Summary, D3Section, D3Table, D3Chart, D3Conclusion],
    labels: ["Kapak", "Yönetici Özeti", "Bölüm Açılışı", "Mali Tablo", "Borç Servisi", "Sonuç"],
  },
  {
    id: "d4",
    title: "Quiet Paper",
    desc: "Tipografik, sakin, çok beyaz alan. Newsreader italik başlıklar, tek bordo aksan, neredeyse bir kitap bölümü hissi. Roma rakamları, klasik tipografi. Zarif ama az gösterişli.",
    tags: ["Italic Serif", "Krem zemin", "Bordo aksan", "Tipografik / Editöryel"],
    slides: [D4Cover, D4Summary, D4Section, D4Table, D4Chart, D4Conclusion],
    labels: ["Kapak", "Yönetici Özeti", "Bölüm Açılışı", "Mali Tablo", "Borç Servisi", "Sonuç"],
  },
];

function App() {
  const [active, setActive] = useState(0);
  const dir = DIRECTIONS[active];

  return (
    <div>
      <div className="tabs">
        {DIRECTIONS.map((d, i) => (
          <button key={d.id} className={`tab ${i === active ? "active" : ""}`} onClick={() => setActive(i)}>
            <span className="num">0{i + 1}</span>{d.title}
          </button>
        ))}
      </div>

      <div className="direction-meta">
        <div style={{ flex: 1 }}>
          <div className="dm-label">YÖN 0{active + 1} / 0{DIRECTIONS.length}</div>
          <div className="dm-title">{dir.title}</div>
          <div className="dm-desc">{dir.desc}</div>
          <div className="dm-tags">
            {dir.tags.map(t => <span key={t} className="dm-tag">{t}</span>)}
          </div>
        </div>
      </div>

      <div className="grid">
        {dir.slides.map((Slide, i) => (
          <div key={i} className="wf-card">
            <div className="wf-label">SL.{String(i + 1).padStart(2, "0")}</div>
            <div className="wf-name">{dir.labels[i]}</div>
            <div className="wf-frame">
              <Slide />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
